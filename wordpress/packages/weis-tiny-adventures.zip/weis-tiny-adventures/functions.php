<?php
/** Theme support and the local content installer. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'after_setup_theme', function () {
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'responsive-embeds' );
    add_editor_style( array( 'assets/site.css', 'assets/wordpress.css', 'assets/editor.css' ) );
} );

add_action( 'wp_enqueue_scripts', function () {
    $uri = get_theme_file_uri();
    wp_enqueue_style( 'wei-original', $uri . '/assets/site.css', array(), '1.0.0' );
    wp_enqueue_style( 'wei-wordpress', $uri . '/assets/wordpress.css', array( 'wei-original' ), '1.0.0' );
    wp_enqueue_script( 'wei-theme', $uri . '/assets/theme.js', array(), '1.0.0', true );
} );

add_filter( 'body_class', function ( $classes ) {
    if ( is_front_page() ) { $classes[] = 'wei-home'; }
    $map = array( 'about-me' => 'about-page', 'travel-tips' => 'tips-page', 'budget-guides' => 'budget-page', 'destinations' => 'atlas-page', 'subscribe' => 'subscribe-page', 'unsubscribe' => 'subscribe-page' );
    foreach ( $map as $slug => $class ) { if ( is_page( $slug ) ) { $classes[] = $class; } }
    if ( is_tax( 'wei_country' ) ) { $classes[] = 'atlas-page'; $classes[] = 'country-journal-page'; }
    return $classes;
} );

add_action( 'init', function () {
    register_block_pattern_category( 'wei-journal', array( 'label' => __( 'Wei’s travel journal', 'weis-tiny-adventures' ) ) );
} );

require_once __DIR__ . '/inc/setup.php';
